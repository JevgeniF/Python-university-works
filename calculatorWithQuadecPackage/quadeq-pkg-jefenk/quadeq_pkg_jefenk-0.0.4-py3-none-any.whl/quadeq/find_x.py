"""Quadratic equation."""

from math import sqrt


def find_x(a, b, c):
    """Finds intersection points of quadratic equation.

    Returns x1; x2, if equation has two different solutions. Returns x, when
    variable a is zero and function intersects x-axis or has two equal
    solutions. Returns "No solutions", if equation has no real solutions.

    :param: a: variable, float
    :param: b: variable, float
    :param: c: variable, float

    :returns: x, or x1; x2, float or "No solutions", string
    """

    if a != 0:
        """Computes equation with discriminant (d)."""
        d = b ** 2 - 4 * a * c
        if d > 0:
            x1 = (- b - sqrt(b ** 2 - 4 * a * c)) / (2 * a)
            x2 = (- b + sqrt(b ** 2 - 4 * a * c)) / (2 * a)
            return x1, x2
        elif d == 0:
            x = - (b / (2 * a))
            if x == - 0.0:
                x = 0.0
            return x
        else:
            return 'No solutions'
    else:
        """Computes linear equation, as a == 0."""
        x = - c / b
        return x
