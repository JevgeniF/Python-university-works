import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="quadeq-pkg-jefenk",  # Replace with your own username
    version="0.0.4",
    author="Jevgeni Fenko",
    author_email="jefenk@taltech.ee",
    description="A package for computing of quadratic equation.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://bitbucket.org/jefenk/quadeq_pkg/src/master/",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
