# Quadratic Equation Homework Package

This is a Quadratic Equation computing package created as part of homework for ICS0019 course of TalTech.
The package finds intersection points of quadratic equation.

Created by Jevgeni Fenko
jefenk@taltech.ee
200810IADB
